//
// Created by jriessner on 03.07.23.
//

#ifndef UTILS_SUBSCRIPTION_H
#define UTILS_SUBSCRIPTION_H


struct subscription {
    u_int id;
    u_int index;
    bool alert;
};

#endif //UTILS_SUBSCRIPTION_H
