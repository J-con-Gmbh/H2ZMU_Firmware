//
// Created by jriessner on 04.07.23.
//

#ifndef UTILS_STRUCTS_H
#define UTILS_STRUCTS_H

struct dataset {
    long x;
    float y;
};

#endif //UTILS_STRUCTS_H
