//
// Created by jriessner on 23.08.2022.
//

#ifndef H2ZMU_2_DATATYPES_H
#define H2ZMU_2_DATATYPES_H

enum datatype {
    INT = 1,
    LONG = 2,
    STRING = 3,
    BOOL = 4,
    FLOAT = 5,
    CHAR = 6
};

#endif //H2ZMU_2_DATATYPES_H
