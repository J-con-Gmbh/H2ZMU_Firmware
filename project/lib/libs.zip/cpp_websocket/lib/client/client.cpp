//
// Created by jriessner on 16.03.23.
//

#include "client.h"

void client::set_server(int _port, std::string ip) {
    this->port = _port;
    this->ip_addr = std::move(ip);
}

void client::client_connect() {

    if ((client_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        printf("\nclient: Socket creation error \n");
        return;
    }
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(port);

    // Convert IPv4 and IPv6 addresses from text to binary
    // form
    if (inet_pton(AF_INET, this->ip_addr.c_str(), &serv_addr.sin_addr)
        <= 0) {
        perror("\nclient: Invalid address/ Address not supported \n");
        return;
    }

    if ( 0 > (status = connect(client_fd, (struct sockaddr*)&serv_addr, sizeof(serv_addr))) ) {
        perror("\nclient: Connection Failed \n");
    }
    this->connected = true;
}

bool client::client_send(const std::string& message) {
    if (!this->connected) {
        return false;
    }
    if (-1 == send(client_fd, message.c_str(), strlen(message.c_str()), 0)) {
        return false;
    }

    return true;
}

bool client::client_receive(std::string *message) {
    RESET_BUFFER(buffer);
    val_read = read(client_fd, (void *)buffer, 1024);
    if (val_read < 0) {
        return false;
    }
    *message = std::string(buffer);

    return true;
}

void client::client_disconnect() {
    this->connected = false;
    close(client_fd);
}

