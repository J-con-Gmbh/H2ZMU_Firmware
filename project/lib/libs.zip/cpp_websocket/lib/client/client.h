//
// Created by jriessner on 16.03.23.
//

#ifndef WEBSOCKET_CLIENT_H
#define WEBSOCKET_CLIENT_H

#include <arpa/inet.h>
#include <cstdio>
#include <cstring>
#include <sys/socket.h>
#include <unistd.h>
#include <string>
#include <cstdlib>
#include <utility>

#include "websocket.h"


#define PORT 55005
#define IP_ADDR "127.0.0.1"

class client {
private:
    bool connected = false;

    int port = PORT;
    std::string ip_addr = IP_ADDR;

    int status, client_fd;
    fd_set readfds;
    long val_read;
    struct sockaddr_in serv_addr;
    char buffer[1024] = {0};

public:
    void set_server(int _port, std::string ip);
    void client_connect();
    bool client_send(const std::string& message);
    bool client_receive(std::string *message);
    void client_disconnect();
};


#endif //WEBSOCKET_CLIENT_H
