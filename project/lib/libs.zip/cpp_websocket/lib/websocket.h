//
// Created by jriessner on 17.03.23.
//

#ifndef WEBSOCKET_H
#define WEBSOCKET_H


#include <vector>
#include <sstream>

#define REQ_OK "ok"
#define REQ_ERR "error"
#define REQ_ERR_SND "error_send"
#define REQ_ERR_REC "error_receive"

#define REQ_SYN "syntax_err"

#define CE "connection_error"
#define NC "error_not_connected"

#define RESET_BUFFER(buffer) ( memset( buffer, '\0', sizeof(buffer) ) )

inline std::vector<std::string> split(const std::string& str, char delim) {
    std::stringstream test(str);
    std::string segment;
    std::vector<std::string> seglist;

    while(std::getline(test, segment, delim))
    {
        seglist.push_back(segment);
    }

    return seglist;
}


#endif //WEBSOCKET_H
