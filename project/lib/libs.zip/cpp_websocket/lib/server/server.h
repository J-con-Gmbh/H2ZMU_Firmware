//
// Created by jriessner on 16.03.23.
//

#ifndef WEBSOCKET_SERVER_H
#define WEBSOCKET_SERVER_H

#define PORT 55005

#include <netinet/in.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <sys/socket.h>
#include <unistd.h>
#include <string>

#include "websocket.h"

#define MAX_CONNECTIONS 30

class server {
protected:
    bool running = false;
    char buffer[1024] = { 0 };

    struct sockaddr_in address;

private:
    bool initialized = false;

    int port = PORT;
    long val_read, val_send;

    int addrlen = sizeof(address);
    int opt = 1;
    int delay_req;

    int master_socket, new_socket, activity, i, valread, sd;
    int max_clients = MAX_CONNECTIONS;
    int *client_socket = nullptr;
    int max_sd;
    fd_set readfds;
    std::string message = "Websocket\r\n";

public:
    void setPort(int _port);
    void setMaxConnections(int maxConnections);
    void initNonBlockingMode(int waitForRequestMillis);
    bool isInitialized();
    void handleNonBlocking();
    virtual bool parseRequest(std::string request, std::string *response) {*response = std::string("ok\r\n"); return true;};
    bool isRunning() { return this->running;};
    ~server();
};


#endif //WEBSOCKET_SERVER_H
