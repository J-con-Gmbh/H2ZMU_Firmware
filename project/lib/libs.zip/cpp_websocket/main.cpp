// Server side C/C++ program to demonstrate Socket
// programming

#include <thread>
#include <iostream>
#include <vector>
#include <algorithm>
#include "client.h"
#include "server.h"

class InputParser {
public:
    InputParser (int &argc, char const* argv[]){
        for (int i=1; i < argc; ++i)
            this->tokens.emplace_back(argv[i]);
    }

    const std::string& getCmdOption(const std::string &option) const{
        std::vector<std::string>::const_iterator itr;
        itr =  std::find(this->tokens.begin(), this->tokens.end(), option);
        if (itr != this->tokens.end() && ++itr != this->tokens.end()){
            return *itr;
        }
        static const std::string empty_string;

        return empty_string;
    }

    std::string getLastCmd() const {
        if (tokens.empty()) {
            return "";
        }
        return this->tokens[tokens.size() - 1];
    }

    bool cmdOptionExists(const std::string &option) const{
        return std::find(this->tokens.begin(), this->tokens.end(), option)
               != this->tokens.end();
    }
private:
    std::vector<std::string> tokens;
};

int main(int argc, char const* argv[]) {
    InputParser input(argc, argv);
    std::string option;
    std::string clnt_data;
    bool clnt = false;
    bool srv = false;
    int port = 0;
    std::string ip;
    try {
        if (input.cmdOptionExists("-p")) {
            port = std::stoi(input.getCmdOption("-p"));
        }
        if (input.cmdOptionExists("-a")) {
            ip = input.getCmdOption("-a");
        }
        if (input.cmdOptionExists("-c")) {
            clnt = true;
        }
        if (input.cmdOptionExists("-s")) {
            srv = true;
        }
        if (input.cmdOptionExists("-d")) {
            clnt_data = input.getCmdOption("-d");
        }
    } catch (std::exception& e) {
        exit(1);
    }
    if (srv && clnt) {
        exit(1);
    }
    if (srv) {
        server _srv;
        if (port > 0) _srv.setPort(port);
        //_srv.init();
        _srv.initNonBlockingMode(0);
        if (!_srv.isInitialized()) {
            perror("Server initialisation failed!");
            return 1;
        }

        while (_srv.isRunning()) {
            _srv.handleNonBlocking();
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }

/*
        bool running = true;

        _srv.start();

        _srv.end();
*/
    } else if (clnt) {
        if (ip.empty() || port <= 0) {
            exit(1);
        }
        client _clnt;
        _clnt.set_server(port, ip);
        _clnt.client_connect();

        std::string response;
        if (_clnt.client_receive(&response)) {
            std::cout << response << std::endl;
        }

        std::string lastArg = input.getLastCmd();

        if (clnt_data.empty()) {
            std::string line;
            std::getline( std::cin, line );
            while (line != "exit") {
                response = "";
                if (_clnt.client_send(line)) {
                    std::cout << "Gesendet: " << line << std::endl;
                }
                if (_clnt.client_receive(&response)) {
                    std::cout << "Empfangen: " << response << std::endl;
                }
                std::getline( std::cin, line );
            }
        } else {
            auto arr = split(clnt_data, ';');
            std::stringstream data;
            for (const auto &item: arr) {
                data << item.c_str() << "\n";
            }
            if ( _clnt.client_send(data.str().c_str()) ) {
                std::string data;
                _clnt.client_receive(&data);
                std::cout << data << std::endl;
            }
        }

        _clnt.client_disconnect();
    }

    /*
    char *msg = "Hallo";

    client clnt;
    clnt.set_server(55005, "127.0.0.1");
    clnt.client_connect();
    std::cout << clnt.client_send(msg) << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(10));
    msg = "exit";
    std::cout << clnt.client_send(msg) << std::endl;
    clnt.client_disconnect();
    */

}
