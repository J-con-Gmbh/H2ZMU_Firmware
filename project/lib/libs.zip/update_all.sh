#!/bin/bash


cd ~/plugins/admin
git pull origin master
cd ../chart
git pull
